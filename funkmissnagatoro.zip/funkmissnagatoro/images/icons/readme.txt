Put your custom character icons here!
Icons must start with "icon-" or it won't be read!
The image resolution must have a minimal of 300x150