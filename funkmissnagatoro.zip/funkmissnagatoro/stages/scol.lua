function onCreate()

	makeLuaSprite('stage','scol/walls',-0.5, 0.5)
	addLuaSprite('stage')
	setProperty('stage.antialiasing',false)
	scaleObject('stage',6,6)

	makeAnimatedLuaSprite('dancers', 'scol/dance', 347.5, 144.5)
	addAnimationByPrefix('dancers','dance','Dance',24,true)
	objectPlayAnimation('dancers','dance',false)
	setProperty('dancers.antialiasing',false)
	scaleObject('dancers',6,6)
	addLuaSprite('dancers')
end